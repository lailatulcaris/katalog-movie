const CONFIG = {
  KEY: '9bb7ea6e79cbf55dcdee81732653bc0f',
  BASE_URL: 'https://api.themoviedb.org/3/',
  BASE_IMAGE_URL: 'https://image.tmdb.org/t/p/w500/',
  DEFAULT_LANGUAGE: 'en-us',
  CACHE_NAME: 'MovieCatalogue-V1',
};

export default CONFIG;
